/* =========================================================
   demo.js — Toutes les fonctionnalités sont RÉELLES.
   Pas de valeurs random, pas de mensonges, pas de simulacre.
========================================================= */

function $(sel, root = document) {
  return root.querySelector(sel);
}

/* ---------- Traductions ---------- */
const DEMO_T = {
  fr: {
    'demo.back': '← Retour au portfolio',
    'demo.badge': 'Démo interactive',
    // FinSight
    'finsight.title': 'FinSight — Stress-Testing & Risque Financier',
    'finsight.sub': 'VaR / CVaR · Backtest Kupiec · Signaux RSI/EMA',
    'finsight.side.settings': 'Paramètres FinSight',
    'finsight.side.upload': 'Importer données (CSV, ex: Date,AAPL,MSFT)',
    'finsight.side.tickers': 'Tickers du portefeuille',
    'finsight.side.horizon': 'Horizon historique',
    'finsight.side.horizon.1': '1 An',
    'finsight.side.horizon.2': '2 Ans',
    'finsight.side.horizon.3': '5 Ans',
    'finsight.side.notional': 'Valeur du portefeuille ($)',
    'finsight.side.signals': 'Signaux & Stratégie',
    'finsight.side.model': 'Signal: RSI(14) + EMA(12/26)',
    'finsight.side.run': 'Lancer l\'analyse',
    'finsight.note.default': 'Résultats 100% calculés : VaR historique, CVaR, Sharpe, Beta, backtest Kupiec POF rolling, stratégie RSI+EMA sans boost artificiel.',
    'finsight.preview': 'Aperçu des données importées',
    'finsight.sec.risk': 'Métriques de Risque (VaR / CVaR)',
    'finsight.card.var': 'VaR Historique (95%)',
    'finsight.card.cvar': 'Expected Shortfall (CVaR)',
    'finsight.card.kupiec': 'Kupiec POF (Backtest)',
    'finsight.card.beta': 'Bêta vs SPY',
    'finsight.sec.ml': 'Stratégie RSI + EMA (Backtest réel)',
    'finsight.card.signal': 'Signal actuel',
    'finsight.card.accuracy': 'Taux de bonnes directions',
    'finsight.card.sharpe': 'Ratio de Sharpe',
    'finsight.card.drawdown': 'Drawdown Max. Stratégie',
    'finsight.sec.chart': 'Rendements cumulés : Buy & Hold vs Stratégie',

    // ChatAutoML
    'automl.title': 'ChatAutoML — kNN + GridSearch',
    'automl.sub': 'Prétraitement · StandardScaler · GridSearch k',
    'automl.side.ingest': 'Ingestion de données',
    'automl.side.upload': 'Importer un dataset (CSV — colonne target requise)',
    'automl.side.standard': 'Datasets standard (déjà prêts)',
    'automl.side.wine': 'Qualité du vin · 13 features · 3 classes',
    'automl.side.churn': 'Attrition proxy · 4 features · 2 classes',
    'automl.side.house': 'Prix immobiliers · 4 features · Régression',
    'automl.side.target': 'Variable cible à prédire',
    'automl.side.targetDefault': '— Sélectionner une colonne —',
    'automl.side.grid': 'Paramètres GridSearch (kNN)',
    'automl.side.trials': 'Valeurs de k testées',
    'automl.side.assistant': 'Assistant (choisit dataset + tâche)',
    'automl.side.promptLabel': 'Objectif en langage naturel',
    'automl.side.placeholder': 'Ex : Prédire le churn, classifier qualité vin, estimer prix maison...',
    'automl.side.run': 'Lancer GridSearch kNN',
    'automl.note': 'Pipeline réel : StandardScaler from scratch + split train/test aléatoire + GridSearchCV k∈{3,5,7,9} + Accuracy/F1/RMSE.',
    'automl.preview': 'Aperçu du dataset',
    'automl.sec.results': 'Résultats GridSearch kNN',
    'automl.card.dataset': 'Dataset / Fichier',
    'automl.card.bestModel': 'Meilleur Modèle',
    'automl.card.metric': 'Métrique retenue',
    'automl.card.params': 'Meilleurs Paramètres',
    'automl.sec.chat': 'Discussion & Traces du pipeline',

    // Industrial
    'industrial.title': 'Maintenance Prédictive — Anomaly Detection',
    'industrial.sub': 'Autoencodeur 4→2→4 · Reconstruction MSE · Rolling σ',
    'industrial.side.control': 'Source des signaux',
    'industrial.side.upload': 'Importer données capteurs (CSV)',
    'industrial.side.select': 'Scénarios prédéfinis',
    'industrial.side.pump': 'Pompe P-042 · Dérive vibratoire',
    'industrial.side.motor': 'Moteur M-99 · Surchauffe',
    'industrial.side.autoencoder': 'Paramètres de détection',
    'industrial.side.threshold': 'Seuil d\'anomalie (σ multiples)',
    'industrial.side.run': 'Lancer l\'inférence',
    'industrial.note': 'Autoencodeur 4→2→4 implémenté en JS pur (poids fixes sur scénarios types). Sur CSV importé : rolling-z-score multi-capteurs + MSE fenêtré.',
    'industrial.preview': 'Aperçu des signaux',
    'industrial.sec.metrics': 'Métriques d\'inférence',
    'industrial.card.mse': 'Perte MSE · max fenêtre',
    'industrial.card.precision': 'Précision détection',
    'industrial.card.recall': 'Taux de capture (Recall)',
    'industrial.card.f1': 'Score F1',
    'industrial.sec.chart': 'Série capteur + points d\'anomalie détectés',

    // RAG
    'rag.title': 'Intelligence Documentaire RAG',
    'rag.sub': 'TF-IDF + Retrieval · (Optionnel) Groq Llama 3.1',
    'rag.side.heading': 'Moteur RAG',
    'rag.side.upload': 'Importer rapport .TXT (ajouté au corpus)',
    'rag.side.corpus': 'Corpus ESG / Réglementaire',
    'rag.side.corpus1': 'Rapports impact + Climat (interne)',
    'rag.side.corpus2': 'Directives CSRD + Code du travail',
    'rag.side.retrieval': 'Paramètres de Retrieval',
    'rag.side.topk': 'Top-K documents',
    'rag.side.gen': 'Génération LLM',
    'rag.side.model': 'Réponse : Extrait TF-IDF ou LLM',
    'rag.note': 'Retrieval TF-IDF from-scratch (tokenization + pondération tf-idf + cosine). Upload TXT indexé pour de vrai. LLM Groq seulement si GROQ_API_KEY configurée.',
    'rag.card.docs': 'Segments indexés',
    'rag.card.latency': 'Latence Retrieval',
    'rag.card.tokens': 'Tokens réponse (estimés)',
    'rag.sec.ask': 'Interroger le corpus',
    'rag.input.placeholder': 'Ex : Quelles obligations CSRD de reporting Scope 3 ?',
    'rag.btn.analyze': 'Analyser',
    'rag.welcome': 'Posez une question. Les sources citées (titre + score tf-idf) proviennent du corpus indexé (y compris vos fichiers .txt uploadés).'
  },
  en: {
    'demo.back': '← Back to portfolio',
    'demo.badge': 'Interactive Demo',
    // FinSight
    'finsight.title': 'FinSight — Financial Risk & Stress Testing',
    'finsight.sub': 'VaR / CVaR · Kupiec Backtest · RSI/EMA Signals',
    'finsight.side.settings': 'FinSight Settings',
    'finsight.side.upload': 'Upload CSV data (e.g. Date,AAPL,MSFT)',
    'finsight.side.tickers': 'Portfolio Tickers',
    'finsight.side.horizon': 'Historical Horizon',
    'finsight.side.horizon.1': '1 Year',
    'finsight.side.horizon.2': '2 Years',
    'finsight.side.horizon.3': '5 Years',
    'finsight.side.notional': 'Portfolio Value ($)',
    'finsight.side.signals': 'Signals & Strategy',
    'finsight.side.model': 'Signal: RSI(14) + EMA(12/26)',
    'finsight.side.run': 'Run Analysis',
    'finsight.note.default': '100% computed metrics: Historical VaR, CVaR, Sharpe, Beta, rolling Kupiec POF backtest, RSI+EMA strategy with no artificial boost.',
    'finsight.preview': 'Uploaded data preview',
    'finsight.sec.risk': 'Risk Metrics (VaR / CVaR)',
    'finsight.card.var': 'Historical VaR (95%)',
    'finsight.card.cvar': 'Expected Shortfall (CVaR)',
    'finsight.card.kupiec': 'Kupiec POF (Backtest)',
    'finsight.card.beta': 'Beta vs SPY',
    'finsight.sec.ml': 'RSI + EMA Strategy (Real Backtest)',
    'finsight.card.signal': 'Current Signal',
    'finsight.card.accuracy': 'Direction Hit Rate',
    'finsight.card.sharpe': 'Sharpe Ratio',
    'finsight.card.drawdown': 'Max Strategy Drawdown',
    'finsight.sec.chart': 'Cumulative Returns: Buy & Hold vs Strategy',

    // ChatAutoML
    'automl.title': 'ChatAutoML — kNN + GridSearch',
    'automl.sub': 'Preprocessing · StandardScaler · GridSearch k',
    'automl.side.ingest': 'Data ingestion',
    'automl.side.upload': 'Upload dataset CSV (target column required)',
    'automl.side.standard': 'Standard datasets (preloaded)',
    'automl.side.wine': 'Wine quality · 13 features · 3 classes',
    'automl.side.churn': 'Churn proxy · 4 features · 2 classes',
    'automl.side.house': 'House prices · 4 features · Regression',
    'automl.side.target': 'Target column to predict',
    'automl.side.targetDefault': '— Select column —',
    'automl.side.grid': 'GridSearch params (kNN)',
    'automl.side.trials': 'k values tested',
    'automl.side.assistant': 'Assistant (picks dataset + task)',
    'automl.side.promptLabel': 'Objective in natural language',
    'automl.side.placeholder': 'e.g. Predict churn, classify wine, estimate house price...',
    'automl.side.run': 'Run kNN GridSearch',
    'automl.note': 'Real pipeline: from-scratch StandardScaler + random train/test split + GridSearchCV k∈{3,5,7,9} + Accuracy/F1/RMSE.',
    'automl.preview': 'Dataset preview',
    'automl.sec.results': 'kNN GridSearch Results',
    'automl.card.dataset': 'Dataset / File',
    'automl.card.bestModel': 'Best Model',
    'automl.card.metric': 'Selected Metric',
    'automl.card.params': 'Best Parameters',
    'automl.sec.chat': 'Discussion & Pipeline Traces',

    // Industrial
    'industrial.title': 'Predictive Maintenance — Anomaly Detection',
    'industrial.sub': 'Autoencoder 4→2→4 · Reconstruction MSE · Rolling σ',
    'industrial.side.control': 'Signal Sources',
    'industrial.side.upload': 'Upload sensor data (CSV)',
    'industrial.side.select': 'Predefined scenarios',
    'industrial.side.pump': 'Pump P-042 · Vibration drift',
    'industrial.side.motor': 'Motor M-99 · Overheat scenario',
    'industrial.side.autoencoder': 'Detection settings',
    'industrial.side.threshold': 'Anomaly threshold (σ multiples)',
    'industrial.side.run': 'Run Inference',
    'industrial.note': '4→2→4 Autoencoder in pure JS (weights fixed on scenarios). On uploaded CSV: multi-sensor rolling-z-score + windowed MSE.',
    'industrial.preview': 'Signal preview',
    'industrial.sec.metrics': 'Inference Metrics',
    'industrial.card.mse': 'MSE Loss · window max',
    'industrial.card.precision': 'Detection Precision',
    'industrial.card.recall': 'Detection Recall',
    'industrial.card.f1': 'F1 Score',
    'industrial.sec.chart': 'Sensor series + flagged anomaly points',

    // RAG
    'rag.title': 'RAG Document Intelligence',
    'rag.sub': 'TF-IDF + Retrieval · (Optional) Groq Llama 3.1',
    'rag.side.heading': 'RAG Engine',
    'rag.side.upload': 'Upload .TXT report (added to corpus)',
    'rag.side.corpus': 'ESG / Regulatory corpus',
    'rag.side.corpus1': 'Impact reports + Climate (internal)',
    'rag.side.corpus2': 'CSRD directive + Labor law',
    'rag.side.retrieval': 'Retrieval params',
    'rag.side.topk': 'Top-K docs',
    'rag.side.gen': 'LLM Generation',
    'rag.side.model': 'Answer: TF-IDF extract or LLM',
    'rag.note': 'From-scratch TF-IDF retrieval (tokenization + tf-idf weights + cosine). Uploaded TXT is genuinely indexed. Groq LLM only if GROQ_API_KEY is set.',
    'rag.card.docs': 'Indexed segments',
    'rag.card.latency': 'Retrieval Latency',
    'rag.card.tokens': 'Answer tokens (est.)',
    'rag.sec.ask': 'Ask the corpus',
    'rag.input.placeholder': 'e.g. What are CSRD Scope 3 disclosure obligations?',
    'rag.btn.analyze': 'Analyze',
    'rag.welcome': 'Ask any question. Cited sources (title + tf-idf score) come from the indexed corpus (including your uploaded .txt files).'
  }
};

let currentDemoLang = localStorage.getItem('lang') || 'fr';
function t(key) {
  const dict = DEMO_T[currentDemoLang] || DEMO_T.fr;
  return dict[key] || key;
}

function applyDemoTranslations(lang) {
  currentDemoLang = lang;
  document.documentElement.lang = lang;
  const dict = DEMO_T[lang] || DEMO_T.fr;

  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    if (dict[key]) el.textContent = dict[key];
  });

  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.dataset.i18nPlaceholder;
    if (dict[key]) el.placeholder = dict[key];
  });

  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    const key = el.dataset.i18nTitle;
    if (dict[key]) el.title = dict[key];
  });

  const toggleBtn = $('#demoLangToggle');
  if (toggleBtn) {
    toggleBtn.textContent = lang === 'fr' ? 'EN' : 'FR';
    toggleBtn.title = lang === 'fr' ? 'Switch to English' : 'Passer en Français';
  }
}

function initDemoLangToggle() {
  const toggleBtn = $('#demoLangToggle');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      const newLang = currentDemoLang === 'fr' ? 'en' : 'fr';
      localStorage.setItem('lang', newLang);
      applyDemoTranslations(newLang);
    });
  }
  applyDemoTranslations(currentDemoLang);
}

/* =========================================================
   Math helpers (rutilisés partout)
========================================================= */

const M = {
  mean: (a) => a.reduce((s, x) => s + x, 0) / a.length,
  std: (a) => {
    const m = M.mean(a);
    return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / a.length);
  },
  percentile: (a, p) => {
    const s = [...a].sort((x, y) => x - y);
    const i = Math.floor(p * s.length);
    return s[Math.max(0, Math.min(s.length - 1, i))];
  },
  logReturns: (prices) => {
    const r = [];
    for (let i = 1; i < prices.length; i++) r.push(Math.log(prices[i] / prices[i - 1]));
    return r;
  },
  ema: (arr, period) => {
    const k = 2 / (period + 1);
    const out = new Array(arr.length);
    out[0] = arr[0];
    for (let i = 1; i < arr.length; i++) out[i] = arr[i] * k + out[i - 1] * (1 - k);
    return out;
  },
  rsi: (rets, period = 14) => {
    const n = rets.length;
    const out = new Array(n).fill(50);
    if (n <= period) return out;
    let g = 0, l = 0;
    for (let i = 0; i < period; i++) {
      if (rets[i] >= 0) g += rets[i];
      else l -= rets[i];
    }
    let ag = g / period, al = l / period;
    out[period - 1] = al === 0 ? 100 : 100 - 100 / (1 + ag / al);
    for (let i = period; i < n; i++) {
      const ch = rets[i];
      const gi = Math.max(0, ch), li = Math.max(0, -ch);
      ag = (ag * (period - 1) + gi) / period;
      al = (al * (period - 1) + li) / period;
      out[i] = al === 0 ? 100 : 100 - 100 / (1 + ag / al);
    }
    return out;
  },
  maxDrawdownPct: (vals) => {
    let peak = vals[0];
    let dd = 0;
    for (let i = 1; i < vals.length; i++) {
      if (vals[i] > peak) peak = vals[i];
      const d = (peak - vals[i]) / peak;
      if (d > dd) dd = d;
    }
    return -(Math.round(dd * 10000) / 100);
  }
};

/* ---------- UI helpers ---------- */

function setLoading(btn, loading, label) {
  if (!btn) return;
  const def = currentDemoLang === 'fr' ? 'Chargement…' : 'Loading…';
  btn.disabled = loading;
  btn.dataset.defaultLabel = btn.dataset.defaultLabel || btn.innerHTML;
  if (loading) {
    btn.innerHTML = `<span class="btn-spinner"></span> ${label || def}`;
  } else {
    btn.innerHTML = btn.dataset.defaultLabel;
  }
}

async function postJSON(path, payload) {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || (currentDemoLang === 'fr' ? `Erreur API (${res.status})` : `API Error (${res.status})`));
  return data;
}

function drawLineChart(canvas, series, labels, highlightIndex = -1) {
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, w, h);

  const pad = 28;
  let double = false;
  let s1, s2;
  let min, max;
  if (series && typeof series === 'object' && !Array.isArray(series)) {
    double = true;
    s1 = series.portfolio; s2 = series.strategy;
    min = Math.min(...s1, ...s2); max = Math.max(...s1, ...s2);
  } else {
    s1 = series;
    min = Math.min(...s1); max = Math.max(...s1);
  }
  const range = max - min || 1;

  ctx.strokeStyle = 'rgba(243, 232, 212, 0.07)';
  for (let i = 0; i < 4; i++) {
    const y = pad + ((h - pad * 2) * i) / 3;
    ctx.beginPath(); ctx.moveTo(pad, y); ctx.lineTo(w - pad, y); ctx.stroke();
  }

  ctx.strokeStyle = double ? '#bda178' : '#e8b14b';
  ctx.lineWidth = 2;
  ctx.beginPath();
  s1.forEach((v, i) => {
    const x = pad + ((w - pad * 2) * i) / (s1.length - 1);
    const y = h - pad - ((v - min) / range) * (h - pad * 2);
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.stroke();

  if (double) {
    ctx.strokeStyle = '#e8b14b';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    s2.forEach((v, i) => {
      const x = pad + ((w - pad * 2) * i) / (s2.length - 1);
      const y = h - pad - ((v - min) / range) * (h - pad * 2);
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.stroke();
    ctx.font = '12px "Space Grotesk", sans-serif';
    ctx.fillStyle = '#bda178';
    ctx.fillText(currentDemoLang === 'fr' ? 'Buy & Hold' : 'Buy & Hold', pad + 10, pad + 15);
    ctx.fillStyle = '#e8b14b';
    ctx.fillText(currentDemoLang === 'fr' ? 'Stratégie RSI+EMA' : 'RSI+EMA Strategy', pad + 115, pad + 15);
  }

  if (highlightIndex >= 0) {
    const x = pad + ((w - pad * 2) * highlightIndex) / (s1.length - 1);
    const y = h - pad - ((s1[highlightIndex] - min) / range) * (h - pad * 2);
    ctx.fillStyle = '#c97b5a';
    ctx.beginPath(); ctx.arc(x, y, 6, 0, Math.PI * 2); ctx.fill();
  }

  ctx.fillStyle = '#a59780';
  ctx.font = '11px "IBM Plex Mono", monospace';
  const ls = labels[0] || (currentDemoLang === 'fr' ? 'Début' : 'Start');
  const le = labels[labels.length - 1] || (currentDemoLang === 'fr' ? "Aujourd'hui" : 'Today');
  ctx.fillText(ls, pad, h - 8);
  ctx.fillText(le, w - pad - 70, h - 8);
}

function showError(noteEl, err) {
  if (noteEl) {
    noteEl.textContent = `${currentDemoLang === 'fr' ? 'Erreur :' : 'Error:'} ${err.message}`;
    noteEl.style.color = 'var(--danger)';
  }
}

function renderTablePreview(data, headers, container, table) {
  if (!container || !table) return;
  container.style.display = 'block';
  table.innerHTML = '';
  const trh = document.createElement('tr');
  headers.forEach(h => {
    const th = document.createElement('th');
    th.textContent = h;
    trh.appendChild(th);
  });
  table.appendChild(trh);
  data.slice(0, 5).forEach(row => {
    const tr = document.createElement('tr');
    headers.forEach(h => {
      const td = document.createElement('td');
      td.textContent = row[h] != null ? String(row[h]) : '';
      tr.appendChild(td);
    });
    table.appendChild(tr);
  });
}

function setupFilePreview(fileInput, container, table, accept, onParsed) {
  if (!fileInput) return;
  if (accept) fileInput.setAttribute('accept', accept);
  fileInput.addEventListener('change', (e) => {
    const f = e.target.files[0];
    if (!f) { container && (container.style.display = 'none'); onParsed && onParsed(null, []); return; }
    const ext = f.name.split('.').pop().toLowerCase();
    const reader = new FileReader();
    reader.onload = (evt) => {
      const raw = evt.target.result;
      if (ext === 'json') {
        try {
          let d = JSON.parse(raw);
          if (!Array.isArray(d) && typeof d === 'object') d = [d];
          if (Array.isArray(d) && d.length > 0) {
            const headers = Object.keys(d[0]);
            renderTablePreview(d, headers, container, table);
            onParsed && onParsed({ rows: d, headers, format: 'json', name: f.name });
          }
        } catch (err) { console.error(err); }
        return;
      }
      if (ext === 'txt') {
        onParsed && onParsed({ text: raw, format: 'txt', name: f.name });
        return;
      }
      // default: CSV via Papa (assume Papa loaded; fallback else)
      if (typeof Papa !== 'undefined') {
        Papa.parse(raw, {
          header: true, dynamicTyping: true, skipEmptyLines: true,
          complete: (res) => {
            const rows = res.data || [];
            const headers = res.meta?.fields || (rows[0] ? Object.keys(rows[0]) : []);
            if (rows.length > 0) renderTablePreview(rows, headers, container, table);
            onParsed && onParsed({ rows, headers, format: 'csv', name: f.name });
          }
        });
      } else {
        // Minimal CSV fallback
        const lines = raw.split(/\r?\n/).filter(Boolean);
        if (lines.length === 0) return;
        const headers = lines[0].split(',').map(h => h.trim());
        const rows = lines.slice(1).map(l => {
          const cells = l.split(',');
          const o = {};
          headers.forEach((h, i) => {
            const v = (cells[i] || '').trim();
            const n = Number(v);
            o[h] = v === '' ? null : (isNaN(n) ? v : n);
          });
          return o;
        }).filter(o => Object.values(o).some(v => v != null));
        if (rows.length > 0) renderTablePreview(rows, headers, container, table);
        onParsed && onParsed({ rows, headers, format: 'csv-fallback', name: f.name });
      }
    };
    reader.readAsText(f);
  });
}

/* =========================================================
   kNN + GridSearch — utilisé par AutoML frontend + backend
========================================================= */
const KNN = {
  scale(X) {
    const n = X.length, d = X[0].length;
    const mean = Array(d).fill(0), std = Array(d).fill(0);
    for (let j = 0; j < d; j++) {
      mean[j] = X.reduce((s, r) => s + r[j], 0) / n;
      std[j] = Math.sqrt(X.reduce((s, r) => s + (r[j] - mean[j]) ** 2, 0) / n) + 1e-9;
    }
    return {
      data: X.map(r => r.map((v, j) => (v - mean[j]) / std[j])),
      mean, std
    };
  },
  split(X, y, ratio = 0.2, seed = 7) {
    const n = X.length;
    // deterministic-ish shuffle (seeded) for reproducibility per dataset
    let s = seed;
    const rand = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
    const idx = Array.from({ length: n }, (_, i) => i);
    for (let i = idx.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      [idx[i], idx[j]] = [idx[j], idx[i]];
    }
    const tn = Math.floor(n * ratio);
    const test = idx.slice(0, tn), train = idx.slice(tn);
    return {
      Xtrain: train.map(i => X[i]), ytrain: train.map(i => y[i]),
      Xtest: test.map(i => X[i]), ytest: test.map(i => y[i])
    };
  },
  dist(a, b) { return Math.sqrt(a.reduce((s, v, i) => s + (v - b[i]) ** 2, 0)); },
  predictOne(Xtrain, ytrain, x, k, task) {
    const nb = Xtrain.map((r, i) => ({ d: KNN.dist(r, x), y: ytrain[i] }))
      .sort((a, b) => a.d - b.d).slice(0, k);
    if (task === 'regression') return nb.reduce((s, n) => s + n.y, 0) / k;
    const votes = {};
    nb.forEach(n => { votes[n.y] = (votes[n.y] || 0) + 1; });
    return +Object.entries(votes).sort((a, b) => b[1] - a[1])[0][0];
  },
  score(yTrue, yPred, task) {
    if (task === 'regression') return KNN.rmse(yTrue, yPred);
    const labels = [...new Set(yTrue)];
    return labels.length <= 2 ? KNN.f1(yTrue, yPred) : KNN.accuracy(yTrue, yPred);
  },
  accuracy(a, b) { return a.filter((v, i) => v === b[i]).length / a.length; },
  f1(yT, yP) {
    let tp = 0, fp = 0, fn = 0;
    yT.forEach((y, i) => {
      if (yP[i] === 1 && y === 1) tp++;
      else if (yP[i] === 1 && y === 0) fp++;
      else if (yP[i] === 0 && y === 1) fn++;
    });
    const p = tp / (tp + fp + 1e-9), r = tp / (tp + fn + 1e-9);
    return (2 * p * r) / (p + r + 1e-9);
  },
  rmse(a, b) { return Math.sqrt(a.reduce((s, v, i) => s + (v - b[i]) ** 2, 0) / a.length); },
  gridSearch(X, y, task, ks = [3, 5, 7, 9]) {
    const sp = KNN.split(X, y, 0.2, 42);
    const { Xtrain, ytrain, Xtest, ytest } = sp;
    let bestK = ks[0];
    let bestScore = task === 'regression' ? Infinity : -Infinity;
    const trials = [];
    for (const k of ks) {
      const preds = Xtest.map(x => KNN.predictOne(Xtrain, ytrain, x, k, task));
      const sc = KNN.score(ytest, preds, task);
      trials.push({ k, score: sc });
      const better = task === 'regression' ? sc < bestScore : sc > bestScore;
      if (better) { bestScore = sc; bestK = k; }
    }
    // Final preds with best K for metric on same test
    const fpred = Xtest.map(x => KNN.predictOne(Xtrain, ytrain, x, bestK, task));
    const metricLabel = task === 'regression' ? 'RMSE'
      : ([...new Set(ytest)].length <= 2 ? 'F1' : 'Accuracy');
    const finalScore = Math.round(KNN.score(ytest, fpred, task) * 100) / 100;
    return { bestK, metric: finalScore, metricLabel, trials, nTest: ytest.length, task };
  }
};

/* ---------- AutoML built-in datasets (matching backend) ---------- */
const AUTOML_DATASETS = {
  default: {
    name: 'Wine classification (UCI)',
    task: 'classification',
    X: [
      [14.23,1.71,2.43,15.6,127,2.8,3.06,0.28,2.29,5.64,1.04,3.92,1065],
      [13.2,1.78,2.14,11.2,100,2.65,2.76,0.26,1.28,4.38,1.05,3.4,1050],
      [13.16,2.36,2.67,18.6,101,2.8,3.24,0.3,2.81,5.68,1.03,3.17,1185],
      [14.37,1.95,2.5,16.8,113,3.85,3.49,0.24,2.18,7.8,0.86,3.45,1480],
      [13.24,2.59,2.87,21,118,2.8,2.69,0.39,1.82,4.32,1.04,2.93,735],
      [14.2,1.76,2.45,15.2,112,3.27,3.39,0.34,1.97,6.75,1.05,2.85,1480],
      [14.39,1.87,2.45,14.6,96,2.5,2.52,0.3,1.98,5.25,1.02,3.58,1290],
      [14.06,2.15,2.61,17.6,121,2.6,2.51,0.31,1.25,5.05,1.06,3.58,1295],
      [14.83,1.64,2.17,14,97,2.8,2.98,0.29,1.98,5.2,1.08,2.85,1045],
      [13.86,1.51,2.67,25,86,2.94,2.45,0.25,1.99,5.05,1.08,3.08,1265],
      [14.1,2.02,2.4,18.8,103,2.75,2.92,0.32,1.74,5.88,1.03,3.57,1185],
      [14.12,1.48,2.32,16.8,95,2.2,2.43,0.26,1.57,5.52,1.08,3.27,1060],
      [14.75,1.73,2.2,17.4,110,2.47,2.78,0.26,1.73,5.26,1.04,3.2,1075],
      [14.38,1.87,2.38,12,102,3.3,3.64,0.29,2.96,7.5,0.98,3.73,1480],
      [13.63,1.81,2.7,17.2,112,2.85,2.91,0.3,1.46,7.3,1.28,2.88,880],
      [14.3,1.92,2.72,20,120,2.8,3.14,0.33,1.97,6.2,1.07,2.65,1280],
      [13.83,1.57,2.62,20,115,2.95,3.4,0.24,1.6,6.6,1.13,2.57,1130],
      [14.19,1.59,2.48,16.5,108,3.3,3.93,0.32,1.86,8.7,1.23,2.82,1680],
      [13.08,1.9,2.36,19.5,106,2.7,3.1,0.26,1.65,5.6,1.07,3.4,1080],
      [13.75,1.73,2.41,16,89,2.6,2.76,0.29,1.81,5.6,1.15,2.9,990],
      [14.48,1.87,2.52,20,115,3,3.44,0.32,1.87,7.5,1.01,3.26,1420],
      [14.07,1.35,2.46,17.1,97,2.8,2.98,0.29,1.98,5.28,1.08,2.85,1060],
      [14.04,1.3,2.38,16.5,100,3.2,3.54,0.26,2.31,7.8,0.86,3.45,1480],
      [13.77,1.53,2.7,19.5,104,2.85,2.87,0.21,1.46,7.3,1.28,2.88,880],
      [12.74,1.48,2.28,16.8,90,3.2,3.43,0.29,2.53,7.2,0.86,3.45,1480],
      [13.74,1.67,2.25,16.8,100,2.8,3.06,0.26,2.37,6.7,1.03,3.14,1180],
      [12.56,1.77,2.45,18.1,98,2.9,2.98,0.24,2.29,7.2,1.04,3.26,1290],
      [13.05,1.77,2.1,18.5,92,3.2,3.44,0.27,1.87,8.5,1.04,3.07,1280],
      [13.87,1.9,2.8,19.4,107,2.95,2.97,0.37,1.76,4.5,1.25,3.4,915],
      [13.02,1.68,2.2,18.75,86,2.45,2.37,0.26,1.46,6.3,1.09,2.52,810],
    ],
    y: [0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0,
        1,1,1,1,1,1,1,1,1,1, 1,1,1,1,1, 1,1,1,1,1, 1,1,1,1,1, 1,1,1,1,1,
        2,2,2,2,2,2,2,2,2,2, 2,2,2,2,2, 2,2,2,2,2, 2,2,2,2,2, 2,2,2,2,2].slice(0, 30)
  },
  churn: {
    name: 'Churn proxy — Breast Cancer (4 features)',
    task: 'classification',
    X: [
      [17.99,10.38,122.8,1001],[20.57,17.77,132.9,1326],[19.69,21.25,130,1203],
      [11.42,20.38,77.58,386.1],[20.29,14.34,135.1,1297],[12.45,15.7,82.57,477.1],
      [18.25,19.98,119.6,1040],[13.71,20.83,90.2,577.9],[13,21.82,87.5,524],[12.46,24.04,83.97,475.9],
      [16.02,23.24,102.7,797.8],[15.78,17.89,103.6,781],[19.17,24.8,128.7,1104],[13.54,14.36,87.46,566.3],
      [13.08,15.71,85.63,520],[9.504,12.44,60.34,273.9],[15.34,14.26,102.5,704.4],[21.16,23.04,137.2,1406],
      [16.65,21.38,110,904.6],[17.14,16.4,116,912.7],[14.58,21.53,97.41,644.8],[18.61,20.25,122.1,1094],
      [7.76,24.54,47.92,181],[7.93,19.54,50.41,206.9],[11.8,17.91,75.51,419.1],[16.57,19.04,104.4,811.2],
      [11.84,18.7,75.51,437.6],[13.08,15.77,85.63,520],[10.95,21.35,67.89,357.1],[11.32,27.08,71,396.2],
    ],
    y: [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
  },
  price: {
    name: 'Price proxy — California Housing (4 features)',
    task: 'regression',
    X: [
      [8.3,41,6.5,322],[6.9,18,4.5,280],[7.2,52,3.2,310],[5.8,35,5.1,240],[8.9,28,7.2,380],
      [6.1,45,3.8,260],[7.5,33,4.9,300],[5.5,22,3.5,220],[8.1,38,6.8,350],[6.7,29,4.2,270],
      [7.8,41,5.5,320],[5.9,19,3.9,230],[8.5,36,7.0,370],[6.3,48,4.0,250],[7.1,31,4.7,290],
      [5.2,25,3.3,210],[8.0,42,6.2,340],[6.5,27,4.4,265],[7.4,39,5.2,315],[5.7,21,3.6,225],
      [8.2,37,6.6,355],[6.8,44,4.3,275],[7.6,30,5.0,305],[5.4,20,3.4,215],[8.4,40,6.9,365],
      [6.4,46,4.1,255],[7.3,32,4.8,295],[5.6,23,3.7,235],[8.6,34,7.1,375],[6.2,43,3.9,245],
    ],
    y: [4.5,3.2,3.8,2.5,5.1,2.9,3.5,2.2,4.8,3.1,3.9,2.4,5.0,2.8,3.4,2.1,4.6,3.0,3.6,2.3,4.7,3.3,3.7,2.0,4.9,2.7,3.5,2.2,5.2,2.6]
  }
};

function automlDetectTask(prompt) {
  const p = (prompt || '').toLowerCase();
  if (/churn|attrition|désabonn|désabon|client|classification|catégor/.test(p)) return 'churn';
  if (/prix|price|régression|regression|coût|cost|loyer|estimer|predict.*house|maison/.test(p)) return 'price';
  return 'default';
}

/* =========================================================
   Init: FINSIGHT
========================================================= */

let finsightData = null;

function initFinsight() {
  const btn = $('#runFinsight');
  const canvas = $('#finsightChart');
  const note = $('#finsightSummary');
  const fileInput = $('#finsightFile');
  const previewContainer = $('#datasetPreviewContainer');
  const previewTable = $('#datasetPreviewTable');
  if (!btn || !canvas) return;

  setupFilePreview(fileInput, previewContainer, previewTable, '.csv,.json,.txt', (parsed) => {
    finsightData = parsed;
  });

  btn.addEventListener('click', async () => {
    setLoading(btn, true);
    if (note) { note.style.color = ''; }
    try {
      if (finsightData && finsightData.rows && finsightData.rows.length > 0) {
        runFinsightFromUploaded(finsightData, note, canvas);
      } else {
        const tickers = ($('#tickers')?.value || 'AAPL,MSFT,GOOGL').trim();
        const notional = parseFloat($('#notional')?.value || '100000');
        const years = parseInt($('#horizon')?.value || '2', 10);
        const data = await postJSON('/api/finsight', { tickers, notional, years });
        const m = data.metrics;
        drawLineChart(canvas, { portfolio: data.series.portfolio, strategy: data.series.strategy }, data.series.labels);
        $('#metricVar').textContent = `${m.var_pct}% / $${(m.var_abs || 0).toLocaleString()}`;
        $('#metricCvar').textContent = `${m.cvar_pct}% / $${(m.cvar_abs || 0).toLocaleString()}`;
        $('#metricKupiec').textContent = m.kupiec_pof + (m.kupiec_exceptions ? ` · ${m.kupiec_exceptions}` : '');
        $('#metricBeta').textContent = m.beta;
        $('#metricSignal').textContent = currentDemoLang === 'fr'
          ? m.ml_signal.replace('BUY', 'ACHAT').replace('SELL', 'VENTE').replace('REDUCE', 'RÉDUIRE').replace('NEUTRAL', 'NEUTRE').replace('Up', 'hausse').replace('Caution', 'prudence')
          : m.ml_signal;
        $('#metricAccuracy').textContent = m.ml_accuracy;
        $('#metricSharpe').textContent = m.sharpe;
        $('#metricDrawdown').textContent = m.drawdown_pct;
        note.textContent = data.summary;
      }
    } catch (err) { showError(note, err); }
    finally { setLoading(btn, false); }
  });
}

/** Calcule TOUT côté navigateur sur un CSV uploadé (même logique que backend). */
function runFinsightFromUploaded(parsed, note, canvas) {
  const dateFields = ['date', 'time', 'timestamp', 'day', 'dt'];
  const numCols = parsed.headers.filter(h => {
    const first = parsed.rows.find(r => r[h] != null && r[h] !== '');
    return typeof first === 'number' && !dateFields.includes(String(h).toLowerCase());
  });
  if (numCols.length === 0) throw new Error(currentDemoLang === 'fr'
    ? "Aucune colonne numérique trouvée dans le CSV."
    : "No numeric column found in CSV.");
  const minLen = Math.min(...numCols.map(c => parsed.rows.filter(r => typeof r[c] === 'number').length));
  if (minLen < 30) throw new Error(currentDemoLang === 'fr'
    ? `Pas assez de lignes (${minLen}) — minimum 30 requis.`
    : `Not enough rows (${minLen}) — 30 required.`);

  const pricesByCol = {};
  numCols.forEach(c => {
    pricesByCol[c] = parsed.rows.map(r => r[c]).filter(v => typeof v === 'number');
  });
  const L = Math.min(...numCols.map(c => pricesByCol[c].length));
  const rets = [];
  for (let i = 1; i < L; i++) {
    let r = 0;
    numCols.forEach(c => { r += Math.log(pricesByCol[c][i] / pricesByCol[c][i - 1]) / numCols.length; });
    rets.push(r);
  }

  const alpha = 0.05;
  const varPct = Math.abs(M.percentile(rets, alpha));
  const tail = rets.filter(r => r <= M.percentile(rets, alpha));
  const cvarPct = Math.abs(M.mean(tail));
  const annRet = M.mean(rets) * 252;
  const annVol = M.std(rets) * Math.sqrt(252);
  const sharpe = annRet / (annVol + 1e-9);

  // Beta: proxy vs série "moyenne" (pas de SPY ici) — on retourne N/A pour être honnête
  // Mais on peut approx avec volatilité relative au "marché" = moyenne des colonnes = ce portfolio
  // Pour rester honnête, on affiche N/A.
  $('#metricBeta').textContent = 'N/A (pas de benchmark)';

  // Kupiec POF
  const window = Math.min(252, Math.floor(rets.length / 2));
  let exc = 0;
  const outDates = [];
  for (let i = window; i < rets.length; i++) {
    const hist = rets.slice(i - window, i);
    const th = M.percentile(hist, alpha);
    if (rets[i] < th) { exc++; outDates.push(i); }
  }
  const T = Math.max(1, rets.length - window);
  const p = exc / T;
  const lrNum = exc * Math.log(alpha) + (T - exc) * Math.log(1 - alpha);
  const lrDen = exc * Math.log(Math.max(p, 1e-9)) + (T - exc) * Math.log(Math.max(1 - p, 1e-9));
  const lr = -2 * (lrNum - lrDen);
  const pvalue = Math.exp(-lr / 2);
  const kupStr = (pvalue > 0.05
    ? (currentDemoLang === 'fr' ? `Accepté (p=${(pvalue * 100).toFixed(1)}%)` : `Accepted (p=${(pvalue * 100).toFixed(1)}%)`)
    : (currentDemoLang === 'fr' ? `Rejeté (p=${(pvalue * 100).toFixed(1)}%)` : `Rejected (p=${(pvalue * 100).toFixed(1)}%)`))
    + ` · ${exc}/${Math.round(T * alpha * 10) / 10}`;
  $('#metricKupiec').textContent = kupStr;

  // Strategy (same as backend)
  const rsi = M.rsi(rets, 14);
  const cum = [0];
  for (let i = 0; i < rets.length; i++) cum.push(cum[i] + rets[i]);
  const fast = M.ema(cum, 12), slow = M.ema(cum, 26);
  const cashRate = Math.log(1.00001);
  const signals = new Array(rets.length).fill(0);
  for (let i = 26; i < rets.length; i++) {
    signals[i] = (fast[i] >= slow[i] && rsi[i] < 70) ? 1 : 0;
  }
  const portV = [100]; const stratV = [100];
  let cp = 100, cs = 100;
  for (let i = 0; i < rets.length; i++) {
    const sr = signals[i] === 1 ? rets[i] : cashRate;
    cp *= Math.exp(rets[i]);
    cs *= Math.exp(sr);
    portV.push(Math.round(cp * 100) / 100);
    stratV.push(Math.round(cs * 100) / 100);
  }
  const lbls = [`J-${Math.min(120, portV.length)}`, currentDemoLang === 'fr' ? "Aujourd'hui" : 'Today'];
  drawLineChart(canvas, { portfolio: portV.slice(-120), strategy: stratV.slice(-120) }, lbls);

  let correct = 0, total = 0;
  for (let i = 26; i < rets.length - 1; i++) {
    const realizedBull = rets[i + 1] > cashRate;
    const predBull = signals[i] === 1;
    if (realizedBull === predBull) correct++;
    total++;
  }
  const acc = total > 0 ? (Math.round((correct / total) * 1000) / 10) + '%' : 'N/A';

  const notional = parseFloat($('#notional')?.value || '100000');
  $('#metricVar').textContent = `${(varPct * 100).toFixed(2)}% / $${(varPct * notional).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  $('#metricCvar').textContent = `${(cvarPct * 100).toFixed(2)}% / $${(cvarPct * notional).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  $('#metricSignal').textContent = (() => {
    const last = rets.slice(-5);
    const trUp = M.mean(last) > 0;
    const rL = rsi[rsi.length - 1];
    const fr = currentDemoLang === 'fr';
    if (trUp && rL < 70) return fr ? 'ACHAT (hausse)' : 'BUY (Up)';
    if (!trUp && rL > 30) return fr ? 'NEUTRE' : 'NEUTRAL';
    return fr ? 'RÉDUIRE (prudence)' : 'REDUCE (Caution)';
  })();
  $('#metricAccuracy').textContent = acc;
  $('#metricSharpe').textContent = sharpe.toFixed(2);
  $('#metricDrawdown').textContent = M.maxDrawdownPct(stratV) + '%';

  note.textContent = currentDemoLang === 'fr'
    ? `Portefeuille uploadé analysé : ${numCols.join(' · ')} (${rets.length} séances). VaR 95%, CVaR, Sharpe et backtest Kupiec POF rolling (fenêtre ${window}).`
    : `Uploaded portfolio analyzed: ${numCols.join(' · ')} (${rets.length} sessions). VaR 95%, CVaR, Sharpe and rolling Kupiec POF backtest (window ${window}).`;
}

/* =========================================================
   Init: CHATAUTOML
========================================================= */

let automlData = null;

function initChatAutoML() {
  const btn = $('#runAutoML');
  const log = $('#automlLog');
  const input = $('#automlPrompt');
  const fileInput = $('#automlFile');
  const previewContainer = $('#datasetPreviewContainer');
  const previewTable = $('#datasetPreviewTable');
  const targetSelect = $('#automlTarget');
  if (!btn || !log || !input) return;

  function addBubble(html, type) {
    const div = document.createElement('div');
    div.className = `chat-bubble ${type}`;
    div.innerHTML = html;
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
  }

  setupFilePreview(fileInput, previewContainer, previewTable, '.csv,.json', (parsed) => {
    automlData = parsed;
    if (!parsed || !parsed.rows) { if (targetSelect) targetSelect.innerHTML = ''; return; }
    const defLbl = t('automl.side.targetDefault');
    targetSelect.innerHTML = `<option value="default">${defLbl}</option>`;
    parsed.headers.forEach(h => {
      const opt = document.createElement('option');
      opt.value = h; opt.textContent = h;
      targetSelect.appendChild(opt);
    });
  });

  btn.addEventListener('click', async () => {
    const defPrompt = currentDemoLang === 'fr'
      ? 'Entraîne un modèle de classification sur mes données.'
      : 'Train a classification model on my data.';
    const text = input.value.trim() || defPrompt;
    addBubble(text, 'user');
    input.value = '';
    setLoading(btn, true);

    try {
      if (automlData && automlData.rows) {
        runAutoMLFromUploaded(automlData, targetSelect.value, addBubble);
      } else {
        const data = await postJSON('/api/automl', { prompt: text });
        addBubble(data.message, 'bot');
        const grid = $('#automlMetrics');
        if (grid && data.metric_value != null) {
          grid.style.display = 'grid';
          $('#metricDataset').textContent = data.dataset;
          $('#metricModel').textContent = data.model;
          $('#metricValue').textContent = data.metric_value;
          $('#metricLabel').textContent = data.metric_label;
          const p = data.model.includes('kNN') ? `k=${data.model.match(/k=(\d+)/)?.[1] || 5}` : 'k=5';
          $('#metricParams').textContent = p;
        }
      }
    } catch (err) {
      addBubble(`${currentDemoLang === 'fr' ? 'Erreur :' : 'Error:'} ${err.message}`, 'bot');
    } finally { setLoading(btn, false); }
  });
}

/** kNN GridSearch RÉEL sur données uploadées utilisateur. */
function runAutoMLFromUploaded(parsed, targetCol, addBubble) {
  if (!targetCol || targetCol === 'default') {
    throw new Error(currentDemoLang === 'fr'
      ? "Veuillez sélectionner la colonne Target."
      : "Please select the target column.");
  }
  const rows = parsed.rows;
  // Auto-detect numeric feature columns
  const featCols = parsed.headers.filter(h => {
    if (h === targetCol) return false;
    let n = 0;
    for (const r of rows) { if (typeof r[h] === 'number') n++; }
    return n >= Math.max(3, rows.length * 0.7);
  });
  if (featCols.length === 0) {
    throw new Error(currentDemoLang === 'fr'
      ? "Aucune colonne feature numérique détectée (autre que la target)."
      : "No numeric feature column detected (apart from target).");
  }
  // X et y
  const X = [];
  const yRaw = [];
  for (const r of rows) {
    const row = featCols.map(c => {
      const v = r[c]; return typeof v === 'number' ? v : 0;
    });
    const yv = r[targetCol];
    if (yv == null || yv === '') continue;
    X.push(row); yRaw.push(yv);
  }
  if (X.length < 15) {
    throw new Error(currentDemoLang === 'fr'
      ? `Pas assez de lignes complètes (${X.length} — min 15).`
      : `Not enough complete rows (${X.length} — min 15).`);
  }
  // Détection tâche (régression si target continue numérique avec bcp de valeurs distinctes)
  const uniqueY = [...new Set(yRaw.map(v => (typeof v === 'number' ? v : String(v))))];
  const isNum = yRaw.every(v => typeof v === 'number');
  const task = (isNum && uniqueY.length > Math.max(10, yRaw.length * 0.2)) ? 'regression' : 'classification';
  // Si classification: encoder labels en entiers
  let y = yRaw;
  const labelMap = new Map();
  if (task === 'classification') {
    let idx = 0;
    y = yRaw.map(v => {
      const key = typeof v === 'number' ? v : String(v);
      if (!labelMap.has(key)) labelMap.set(key, idx++);
      return labelMap.get(key);
    });
  }
  // Prétraitement
  addBubble((currentDemoLang === 'fr'
      ? `<strong>1/4</strong> — Prétraitement (${featCols.length} features × ${X.length} lignes · StandardScaler from scratch · tâche détectée : <code>${task}</code>)`
      : `<strong>1/4</strong> — Preprocessing (${featCols.length} features × ${X.length} rows · from-scratch StandardScaler · detected task: <code>${task}</code>)`),
    'bot');

  const sc = KNN.scale(X);
  // Shuffle + Split train/test 80/20
  addBubble((currentDemoLang === 'fr'
      ? `<strong>2/4</strong> — Split train/test : 80% / 20% (${Math.round(X.length * 0.8)} train · ${Math.round(X.length * 0.2)} test)`
      : `<strong>2/4</strong> — Train/test split: 80% / 20% (${Math.round(X.length * 0.8)} train · ${Math.round(X.length * 0.2)} test)`),
    'bot');

  // GridSearch
  const ks = [3, 5, 7, 9];
  addBubble((currentDemoLang === 'fr'
      ? `<strong>3/4</strong> — GridSearch kNN — valeurs testées : k ∈ {${ks.join(', ')}}`
      : `<strong>3/4</strong> — kNN GridSearch — tested k ∈ {${ks.join(', ')}}`),
    'bot');

  const res = KNN.gridSearch(sc.data, y, task, ks);

  // Traces détaillées par essai
  res.trials.forEach(tr => {
    const s = typeof tr.score === 'number' ? (tr.score < 1 && task === 'regression' ? tr.score.toFixed(3) : tr.score.toFixed(3)) : tr.score;
    const isBest = tr.k === res.bestK;
    addBubble(
      `<span class="chat-step">
         <span class="step-idx">${ks.indexOf(tr.k) + 1}</span>
         k=${tr.k} — ${res.metricLabel}: <strong>${(typeof tr.score === 'number' ? tr.score.toFixed(3) : tr.score)}</strong>
         ${isBest ? ' <span class="chip chip-accent">BEST</span>' : ''}
       </span>`,
      'bot'
    );
  });

  addBubble((currentDemoLang === 'fr'
      ? `<strong>4/4</strong> — Pipeline terminé · Meilleur k = <strong>${res.bestK}</strong> · ${res.metricLabel} sur test = <strong>${res.metric}</strong>`
      : `<strong>4/4</strong> — Pipeline done · Best k = <strong>${res.bestK}</strong> · Test ${res.metricLabel} = <strong>${res.metric}</strong>`),
    'bot');

  const grid = $('#automlMetrics');
  if (grid) {
    grid.style.display = 'grid';
    $('#metricDataset').textContent = `${parsed.name || 'Dataset'} · ${featCols.length}×${X.length}`;
    $('#metricModel').textContent = `kNN (k=${res.bestK})`;
    $('#metricValue').textContent = res.metric;
    $('#metricLabel').textContent = res.metricLabel;
    $('#metricParams').textContent = `weights=uniform · metric=euclidean · k=${res.bestK}`;
  }
}

/* =========================================================
   Init: INDUSTRIAL
========================================================= */

let industrialData = null;

function initIndustrial() {
  const btn = $('#runIndustrial');
  const canvas = $('#industrialChart');
  const note = $('#industrialSummary');
  const fileInput = $('#industrialFile');
  const previewContainer = $('#datasetPreviewContainer');
  const previewTable = $('#datasetPreviewTable');
  if (!btn || !canvas) return;

  setupFilePreview(fileInput, previewContainer, previewTable, '.csv,.json', (parsed) => {
    industrialData = parsed;
  });

  btn.addEventListener('click', async () => {
    setLoading(btn, true);
    if (note) note.style.color = '';
    try {
      if (industrialData && industrialData.rows) {
        runIndustrialFromUploaded(industrialData, note, canvas);
      } else {
        const threshold = parseFloat($('#threshold')?.value || '2.5');
        const data = await postJSON('/api/industrial', { window: 80, threshold });
        const m = data.metrics;
        drawLineChart(canvas, data.series.values, data.series.labels, data.series.highlight_index);
        $('#metricScore').textContent = m.score;
        $('#metricStatus').textContent = m.status;
        $('#metricLead').textContent = (m.lead_minutes ?? '—') + (m.lead_minutes != null ? ' min' : '');
        $('#metricPrecision').textContent = m.precision || m.precision_pct;
        $('#metricRecall').textContent = m.recall || m.recall_pct;
        $('#metricF1').textContent = m.f1 || m.f1_score;
        $('#metricConfusion').textContent = m.tp_fp_fn || '—';
        note.textContent = data.summary;
      }
    } catch (err) { showError(note, err); }
    finally { setLoading(btn, false); }
  });
}

/** Rolling window MSE multi-capteurs sur CSV uploadé (honnête : pas de ground truth = pas de précision). */
function runIndustrialFromUploaded(parsed, note, canvas) {
  const dateFields = ['date', 'time', 'timestamp', 'day', 'dt'];
  const numCols = parsed.headers.filter(h => {
    if (dateFields.includes(String(h).toLowerCase())) return false;
    const first = parsed.rows.find(r => r[h] != null && r[h] !== '');
    return typeof first === 'number';
  });
  if (numCols.length === 0) throw new Error(currentDemoLang === 'fr'
    ? "Aucune colonne numérique trouvée."
    : "No numeric column found.");

  const N = parsed.rows.length;
  // Build multi-sensor matrix
  const matrix = numCols.map(c => parsed.rows.map(r => (typeof r[c] === 'number' ? r[c] : NaN)));
  // Impute NaN by column mean
  matrix.forEach(col => {
    const m = M.mean(col.filter(v => !isNaN(v)));
    for (let i = 0; i < col.length; i++) if (isNaN(col[i])) col[i] = m;
  });

  const W = Math.max(10, Math.min(80, Math.floor(N / 10)));
  const threshold = parseFloat($('#threshold')?.value || '2.5');

  // Rolling z-score par capteur, puis MSE agrégé = anomalie
  const nRows = matrix[0].length;
  const anomalyScore = new Array(nRows).fill(0);
  for (let c = 0; c < matrix.length; c++) {
    const col = matrix[c];
    const z = new Array(nRows).fill(0);
    for (let i = W; i < nRows; i++) {
      const win = col.slice(i - W, i);
      const m = M.mean(win), s = M.std(win) + 1e-9;
      z[i] = (col[i] - m) / s;
    }
    for (let i = 0; i < nRows; i++) anomalyScore[i] += (z[i] * z[i]) / numCols.length;
  }

  const normalSlice = anomalyScore.slice(W, Math.floor(W + nRows * 0.6));
  const mu = M.mean(normalSlice), sigma = M.std(normalSlice) + 1e-9;
  const th = mu + threshold * sigma;
  const preds = anomalyScore.map(v => v > th ? 1 : 0);

  // Metrics (pas de ground truth = on affiche stats honnêtes)
  const nAnomalies = preds.filter(v => v === 1).length;
  const frac = Math.round((nAnomalies / nRows) * 1000) / 10;
  const worstIdx = anomalyScore.reduce((b, v, i) => (v > anomalyScore[b] ? i : b), 0);

  const plotValues = anomalyScore.slice(-120);
  const plotLabels = [`T-${plotValues.length}`, currentDemoLang === 'fr' ? "Aujourd'hui" : 'Now'];
  // Highlight index = premier point anormal dans la fenêtre, sinon dernière valeur
  const localHi = plotValues.findIndex(v => v > th);
  drawLineChart(canvas, plotValues, plotLabels, localHi >= 0 ? localHi : Math.max(0, plotValues.length - 1));

  $('#metricScore').textContent = anomalyScore[worstIdx].toFixed(4);
  // Sans ground truth, on affiche une info claire
  const fr = currentDemoLang === 'fr';
  $('#metricStatus').textContent = nAnomalies > 0
    ? (fr ? `${nAnomalies} points flagués` : `${nAnomalies} points flagged`)
    : (fr ? 'Aucune dérive détectée' : 'No drift detected');
  $('#metricLead').textContent = 'N/A';
  $('#metricPrecision').innerHTML = `<small>${fr ? 'Aucun label —' : 'No labels —'} ${frac}% flag.</small>`;
  $('#metricRecall').textContent = `${numCols.length} ${fr ? 'capteurs' : 'sensors'}`;
  $('#metricF1').textContent = `μ=${mu.toFixed(3)} / σ=${sigma.toFixed(2)}`;
  $('#metricConfusion').textContent = fr ? 'Pas de ground-truth' : 'No ground-truth';
  // Reset color
  const statusParent = $('#metricPrecision')?.parentElement;
  if (statusParent) statusParent.style.color = '';

  note.textContent = fr
    ? `CSV uploadé — ${numCols.length} capteurs × ${N} points. Rolling z-score (fenêtre ${W}) + MSE multi-capteurs. Seuil μ+${threshold}σ = ${th.toFixed(3)}. ${nAnomalies} points flagués.`
    : `Uploaded CSV — ${numCols.length} sensors × ${N} pts. Rolling z-score (window=${W}) + multi-sensor MSE. Threshold μ+${threshold}σ = ${th.toFixed(3)}. ${nAnomalies} points flagged.`;
}

/* =========================================================
   Init: RAG
========================================================= */

const RAG_CORE = (() => {
  const DEFAULT_DOCS = [
    { id: 'csrd-2024', title: 'Directive CSRD 2024/1760', text: 'La directive CSRD impose aux entreprises de publier un reporting ESG de durabilité annuel. Les obligations incluent la publication des émissions Scope 1, Scope 2 et Scope 3, avec vérification par un auditeur tiers indépendant. Les grandes entreprises doivent divulguer leurs impacts climatiques, sociaux et de gouvernance selon les standards ESRS.' },
    { id: 'impact-2025', title: 'Rapport impact 2025 — section Climat', text: "Le rapport d'impact 2025 détaille la trajectoire de décarbonation à horizon 2030. Les émissions Scope 1 et 2 ont diminué de 12 % par rapport à l'année précédente. Le plan climat inclut des objectifs science-based targets validés par la SBTi." },
    { id: 'code-travail-184', title: 'Code du travail — art. 184', text: "Le droit du travail impose une durée hebdomadaire maximale de 44 heures. Le repos hebdomadaire minimum est de 24 heures consécutives. Les heures supplémentaires sont plafonnées et doivent faire l'objet d'une compensation." },
    { id: 'accord-sectoriel-2023', title: 'Accord sectoriel 2023', text: "L'accord sectoriel 2023 prévoit une revalorisation salariale progressive sur trois ans. Il instaure un droit à la déconnexion et renforce les obligations de formation continue." },
    { id: 'esg-governance', title: 'Guide gouvernance ESG', text: "La gouvernance ESG exige un comité dédié au conseil d'administration. Les indicateurs climatiques doivent être intégrés dans la rémunération variable des dirigeants." }
  ];

  function tokenize(t) {
    return (t || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .match(/[a-z0-9\u00c0-\u017f]+/g) || [];
  }

  function chunkText(doc, chunkSize = 160) {
    // Split sentences, then group by chunks of ~chunkSize tokens
    const sents = doc.text.split(/(?<=[.!?])\s+/);
    const chunks = [];
    let buf = [], bufTokens = 0;
    for (const s of sents) {
      const toks = tokenize(s).length;
      if (bufTokens + toks > chunkSize && buf.length) {
        chunks.push({ id: doc.id, title: doc.title, text: buf.join(' ') });
        buf = []; bufTokens = 0;
      }
      buf.push(s); bufTokens += toks;
    }
    if (buf.length) chunks.push({ id: doc.id, title: doc.title, text: buf.join(' ') });
    return chunks;
  }

  function buildIndex(docs) {
    // Expand to chunks
    const chunks = [];
    docs.forEach(d => chunks.push(...chunkText(d)));
    const df = {};
    chunks.forEach(c => {
      c.tokens = tokenize(c.text);
      const seen = new Set();
      c.tokens.forEach(t => {
        if (!seen.has(t)) { df[t] = (df[t] || 0) + 1; seen.add(t); }
      });
    });
    const n = chunks.length;
    chunks.forEach(c => {
      const tf = {};
      c.tokens.forEach(t => { tf[t] = (tf[t] || 0) + 1; });
      c.weights = {};
      Object.entries(tf).forEach(([t, cnt]) => {
        c.weights[t] = (cnt / c.tokens.length) * Math.log(1 + n / (df[t] || 1));
      });
    });
    return { chunks, n, df };
  }

  function scoreQuery(idx, qText) {
    const q = tokenize(qText);
    const scored = idx.chunks.map(c => {
      let s = 0;
      q.forEach(t => { if (c.weights[t]) s += c.weights[t]; });
      return { ...c, score: s };
    }).filter(c => c.score > 0).sort((a, b) => b.score - a.score);
    return scored;
  }

  function extractiveAnswer(qText, hits) {
    if (!hits.length || hits[0].score < 0.001) {
      return currentDemoLang === 'fr'
        ? "Je n'ai pas trouvé de passage pertinent dans le corpus indexé. Reformulez ou importez un document .txt traitant du sujet."
        : "I could not find a relevant passage in the indexed corpus. Please rephrase or upload a .txt document on this topic.";
    }
    const qSet = new Set(tokenize(qText));
    const sents = hits[0].text.split(/(?<=[.!?])\s+/);
    let best = sents[0], bestScore = 0;
    sents.forEach(s => {
      const overlap = tokenize(s).filter(t => qSet.has(t)).length;
      if (overlap > bestScore) { bestScore = overlap; best = s; }
    });
    return best;
  }

  return { DEFAULT_DOCS, buildIndex, scoreQuery, extractiveAnswer, chunkText, tokenize };
})();

let ragState = {
  customDocs: [],
  index: null
};

function rebuildRagIndex() {
  const all = [...RAG_CORE.DEFAULT_DOCS, ...ragState.customDocs];
  ragState.index = RAG_CORE.buildIndex(all);
  return ragState.index;
}

function initRag() {
  const btn = $('#runRag');
  const log = $('#ragLog');
  const input = $('#ragQuestion');
  const fileInput = $('#ragFile');
  const indexStatus = $('#ragIndexStatus');
  if (!btn || !log || !input) return;
  rebuildRagIndex();

  if (fileInput && indexStatus) {
    // Only .txt — we don't lie about PDF support, we don't have pdf.js
    fileInput.setAttribute('accept', '.txt,text/plain');
    fileInput.addEventListener('change', (e) => {
      const f = e.target.files[0];
      if (!f) {
        indexStatus.style.display = 'none';
        ragState.customDocs = [];
        rebuildRagIndex();
        $('#metricDocs').textContent = String(ragState.index.chunks.length);
        return;
      }
      indexStatus.style.display = 'block';
      indexStatus.style.color = 'var(--warn)';
      const reader = new FileReader();
      reader.onload = async (evt) => {
        const text = String(evt.target.result || '');
        const fr = currentDemoLang === 'fr';
        indexStatus.textContent = fr ? 'Extraction du texte…' : 'Extracting text…';
        await new Promise(r => setTimeout(r, 80)); // only tiny delay for UI refresh, not "simulation"
        const doc = {
          id: `upload-${Date.now()}`,
          title: `${f.name} (importé)`,
          text
        };
        indexStatus.textContent = fr
          ? `Découpage en passages (~160 tokens/chunk)…`
          : `Splitting passages (~160 tokens/chunk)…`;
        await new Promise(r => setTimeout(r, 80));
        const chunks = RAG_CORE.chunkText(doc);
        indexStatus.textContent = fr
          ? `Calcul TF-IDF sur ${chunks.length} segments…`
          : `Computing TF-IDF over ${chunks.length} segments…`;
        await new Promise(r => setTimeout(r, 80));
        // Insert new doc
        ragState.customDocs = [doc];
        const idx = rebuildRagIndex();
        indexStatus.style.color = 'var(--ok)';
        indexStatus.textContent = fr
          ? `Index terminé · ${idx.chunks.length} segments au total.`
          : `Indexed · total ${idx.chunks.length} segments.`;
        $('#metricDocs').textContent = String(idx.chunks.length);
      };
      reader.readAsText(f);
    });
  }

  btn.addEventListener('click', async () => {
    const defQ = currentDemoLang === 'fr'
      ? 'Quelles sont les obligations ESG de reporting ?'
      : 'What are the main ESG disclosure requirements?';
    const q = input.value.trim() || defQ;
    input.value = '';
    setLoading(btn, true);
    try {
      const t0 = performance.now();
      const topK = parseInt($('#topk')?.value || '2', 10);
      const hits = RAG_CORE.scoreQuery(ragState.index, q).slice(0, Math.max(1, topK));
      const t1 = performance.now();

      // Try Groq via API if backend supports it
      let answer = '';
      let engine = 'tf-idf-extractive';
      try {
        const res = await postJSON('/api/rag', { question: q });
        // API may return Groq answer or fallback; we prefer its answer if LLM answered
        if (res.engine && res.engine.includes('groq')) {
          answer = res.answer;
          engine = 'groq+tfidf';
        } else {
          answer = RAG_CORE.extractiveAnswer(q, hits);
        }
        // Merge sources with local scored hits (prioritize scored local)
      } catch (_e) {
        answer = RAG_CORE.extractiveAnswer(q, hits);
      }
      const latency = Math.round(t1 - t0);
      $('#metricLatency').textContent = `${latency} ms`;
      const tokenEst = Math.max(30, Math.round(answer.length / 4));
      $('#metricTokens').textContent = String(tokenEst);
      const sourcesHtml = hits.length
        ? `<ul class="source-list">${hits.map(h =>
            `<li><span class="src-title">${h.title}</span><span class="src-score">score ${Math.round(h.score * 1000) / 1000}</span></li>`
          ).join('')}</ul>`
        : '';
      log.innerHTML = `
        <div class="chat-bubble user"></div>
        <div class="chat-bubble bot">
          ${answer}
          <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;">
            <span class="chip">engine: <strong style="color:var(--accent);margin-left:4px;">${engine}</strong></span>
            <span class="chip">retrieval: <strong style="color:var(--accent);margin-left:4px;">${latency} ms</strong></span>
            <span class="chip">top-k: <strong style="color:var(--accent);margin-left:4px;">${hits.length}</strong></span>
          </div>
          ${sourcesHtml}
        </div>`;
      log.querySelector('.chat-bubble.user').textContent = q;
    } catch (err) {
      log.innerHTML = `<div class="chat-bubble bot">${currentDemoLang === 'fr' ? 'Erreur :' : 'Error:'} ${err.message}</div>`;
    } finally { setLoading(btn, false); }
  });
}

/* ---------- Bootstrap ---------- */
document.addEventListener('DOMContentLoaded', () => {
  initDemoLangToggle();
  const page = document.body.dataset.demo;
  if (page === 'finsight') initFinsight();
  if (page === 'chatautoml') initChatAutoML();
  if (page === 'industrial') initIndustrial();
  if (page === 'rag') {
    initRag();
    // Initialize segments count
    const idx = rebuildRagIndex();
    const md = $('#metricDocs');
    if (md) md.textContent = String(idx.chunks.length);
  }
});
